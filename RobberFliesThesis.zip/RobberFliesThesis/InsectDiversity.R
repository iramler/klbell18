# Karina L. Bellavia
# This R file is used for the insect diversity portion of my Honors Thesis on Lasiopogon currani

# Packages
library(dplyr)
library(ggplot2)
library(readxl)
library(tidyr)

 # Insert data for malaise trap diversity
insectdiversity_mal <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 8)

# Pivot data
insectdiversity_mal_long <- insectdiversity_mal %>%
  pivot_longer(cols = -1, names_to = "Order", values_to = "Insects") %>%
  filter(!is.na(Insects))

# Make graph 
ggplot(data = insectdiversity_mal_long, mapping = aes(x = Date, y = log(Insects), fill = Order)) +
  geom_bar(position='dodge', stat='identity') +
  labs(x = "2021 Date", y = "Log Number of Insects", title = "Malaise Trap") +
  theme(
        legend.margin = margin(6, 6, 6, 6),
        text = element_text(size=12, family = "CM Roman"), 
        plot.title = element_text(color = "black", face="bold", size=16, hjust=0))

# Insert data for malaise trap diversity
insectdiversity_pan <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 9)

# Pivot data
insectdiversity_pan_long <- insectdiversity_pan %>%
  pivot_longer(cols = -1, names_to = "Order", values_to = "Insects") %>%
  filter(!is.na(Insects))

range2 <- c(as.Date("2021-04-28"), as.Date("2021-05-06"), as.Date("2021-05-13"), as.Date("2021-05-18"), as.Date("2021-05-27"), as.Date("2021-06-02"), as.Date("2021-06-10"))

# Make graph 
ggplot(data = insectdiversity_pan_long, mapping = aes(x = Date, y = log(Insects), fill = Order)) +
  geom_bar(position='dodge', stat='identity') +
  labs(x = "2021 Date", y = "Log Number of Insects", title = "Pan Trap") +
  theme(
    legend.margin = margin(6, 6, 6, 6),
    text = element_text(size=12, family = "CM Roman"), 
    plot.title = element_text(color = "black", face="bold", size=16, hjust=0))

?scale_x_date

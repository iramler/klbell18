# Packages
library(dplyr)
library(ggplot2)
library(readxl)
library(tidyr)
library(cowplot)
library(knitr)

# Insert data
malaise <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 5)

malaisetable <- malaise %>%
  group_by(Order, Family) %>%
  summarise(
    n = sum(Number)
  )

table <- tibble(malaisetable)

pan <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 6)

pantable <- pan %>%
  group_by(Order, Family) %>%
  summarise(
    n = sum(Number)
  )

kable(pantable)


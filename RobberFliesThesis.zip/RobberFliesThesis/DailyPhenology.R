# Karina L. Bellavia
# This R file is used for the daily phenology portion of my Honors Thesis on Lasiopogon currani

# Packages
library(dplyr)
library(ggplot2)
library(readxl)
library(tidyr)
library(cowplot)

# Insert data
luxreading <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 2)

# Option 1 for West Zones
df <- gather(luxreading, key = measure, value = Rate, 
             c("AverageLuxWest", "AverageFliesWest"))

ggplot(df, aes(x = Time, y = Rate, color = measure)) +
  geom_line() +
  scale_y_continuous(sec.axis = sec_axis(~./8000, name = "Average Number of Flies")) +
  labs(x = "Time", y = "Average Lux Intensity", title = "Average Lux and Fly Abundance of West Zones") +
  scale_color_manual(values = c("darkseagreen3", "darkslategray3")) +
  theme(legend.position = c(.95, .95),
        legend.justification = c("right", "top"),
        legend.box.just = "right",
        legend.margin = margin(6, 6, 6, 6),
        text = element_text(size=12, family = "CM Roman"), 
        plot.title = element_text(color = "black", face="bold", size=15, hjust=0))


# Option 2 for West Zones
ggplot(data = luxreading, mapping = aes(x = Time, fill = )) +
  geom_line(aes(y = AverageLuxWest)) +
  geom_line(aes(y = AverageFliesWest)) +
  scale_fill_manual(values = c("Green", "Yellow")) +
  scale_y_continuous(sec.axis = sec_axis(~./8000, name = "Average Number of Flies")) +
  labs(x = "Time", y = "Average Lux Intensity", title = "Average Lux and Fly Abundance of West Zones") +
  theme(legend.position = c(.95, .95),
        legend.justification = c("right", "top"),
        legend.box.just = "right",
        legend.margin = margin(6, 6, 6, 6),
        text = element_text(size=12, family = "CM Roman"), 
        plot.title = element_text(color = "black", face="bold", size=15, hjust=0))

#Option 3 for West Zones

west1 <- ggplot(data = luxreading, mapping = aes(x = Time)) +
  geom_line(aes(y = AverageLuxWest), color = "Red") +
  labs(x = "", y = "Average Lux Intensity", title = "Average Lux Intensity and Fly Abundance\n of West Zones") +
  theme_bw() +
  theme(
        text = element_text(size=10, family = "CM Roman"), 
        plot.title = element_text(color = "black", face="bold", size=15, hjust=0))

west2 <- ggplot(data = luxreading, mapping = aes(x = Time)) +
  geom_line(aes(y = AverageFliesWest), color = "Blue") +
  labs(x = "Time", y = "Average Number of Flies") +
  theme_bw() +
  theme(
    text = element_text(size=10, family = "CM Roman"), 
    plot.title = element_text(color = "black", face="bold", size=15, hjust=0))

plot_grid(west1, west2, ncol = 1)


# Option 1 for East Zones
df2 <- gather(luxreading, key = measure, value = Rate, 
              c("AverageLuxEast", "AverageFliesEast"))

ggplot(df2, aes(x = Time, y = Rate, group = measure, color = measure)) +
  geom_line() +
  scale_y_continuous(sec.axis = sec_axis(~./8000, name = "Average Number of Flies")) +
  labs(x = "Time", y = "Average Lux Intensity", title = "Average Lux and Fly Abundance of East Zones") +
  theme(legend.position = c(.95, .95),
        legend.justification = c("right", "top"),
        legend.box.just = "right",
        legend.margin = margin(6, 6, 6, 6),
        text = element_text(size=12, family = "CM Roman"), 
        plot.title = element_text(color = "black", face="bold", size=15, hjust=0))

# Option 2 for East Zones
ggplot(data = luxreading, mapping = aes(x = Time)) +
  geom_line(aes(y = AverageLuxEast), color = "blue") +
  geom_line(aes(y = AverageFliesEast), color = "red") +
  scale_y_continuous(sec.axis = sec_axis(~./7500, name = "Average Number of Flies")) +
  labs(x = "Time", y = "Average Lux Intensity", title = "Average Lux and Fly Abundance of East Zones") +
  theme(legend.position = c(.95, .95),
        legend.justification = c("right", "top"),
        legend.box.just = "right",
        legend.margin = margin(6, 6, 6, 6),
        text = element_text(size=12, family = "CM Roman"), 
        plot.title = element_text(color = "black", face="bold", size=15, hjust=0))

#Option 3 for West Zones

east1 <- ggplot(data = luxreading, mapping = aes(x = Time)) +
  geom_line(aes(y = AverageLuxEast), color = "Red") +
  labs(x = "", y = "Average Lux Intensity", title = "Average Lux Intensity and Fly Abundance\n of East Zones") +
  theme_bw() +
  theme(
    text = element_text(size=10, family = "CM Roman"), 
    plot.title = element_text(color = "black", face="bold", size=15, hjust=0))

east2 <- ggplot(data = luxreading, mapping = aes(x = Time)) +
  geom_line(aes(y = AverageFliesEast), color = "Blue") +
  labs(x = "Time", y = "Average Number of Flies") +
  theme_bw() +
  theme(
    text = element_text(size=10, family = "CM Roman"), 
    plot.title = element_text(color = "black", face="bold", size=15, hjust=0))

plot_grid(east1, east2, ncol = 1)


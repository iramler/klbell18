# Karina L. Bellavia
# This R file is used for the seasonal phenology portion of my Honors Thesis on Lasiopogon currani

# Packages
library(dplyr)
library(ggplot2)
library(readxl)
library(tidyr)

# Insert data for population abundance
popabundance <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 1)
colnames(popabundance) <- c("Date", "2019", "2021")

# Pivot data
popabundance_long <- popabundance %>%
  pivot_longer(cols = -1, names_to = "Year", values_to = "Flies") %>%
  filter(!is.na(Flies))

# Make graph 
ggplot(data = popabundance_long, mapping = aes(x = Date, y = Flies, color = Year)) +
  geom_line() +
  geom_point() +
  labs(x = "Date", y = "Number of Flies", title = "Population Abundance") +
  theme(legend.position = c(.95, .95),
        legend.justification = c("right", "top"),
        legend.box.just = "right",
        legend.margin = margin(6, 6, 6, 6),
        text = element_text(size=12, family = "CM Roman"), 
        plot.title = element_text(color = "black", face="bold", size=16, hjust=0))

# Insert data for precipitation
precip <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 3)
precip_long <- precip %>%
  pivot_longer(cols = -1, names_to = "Year", values_to = "Precipitation")

# Make Graph
ggplot(data = precip_long, mapping = aes(x = Date, y = Precipitation, color = Year)) +
  geom_line() +
  labs(x = "Date", y = "Precipitation [mm]", title = "Daily Precipitation in Pierrepont, NY") +
  theme(
        legend.margin = margin(6, 6, 6, 6),
        text = element_text(size=12, family = "CM Roman"), 
        plot.title = element_text(color = "black", face="bold", size=16, hjust=0))

# Insert data for temperature
temp <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 4)
temp_long <- temp %>%
  pivot_longer(cols = -1, names_to = "Year", values_to = "Temperature")

# Make Graph
ggplot(data = temp_long, mapping = aes(x = Date, y = Temperature, color = Year)) +
  geom_line() +
  labs(x = "Date", y = "Temperature [C°]", title = "Daily Temperature in Pierrepont, NY") +
  theme(
    legend.margin = margin(6, 6, 6, 6),
    text = element_text(size=12, family = "CM Roman"), 
    plot.title = element_text(color = "black", face="bold", size=16, hjust=0))

cum_precip <- read_excel("~/RobberFliesThesis/Data/RobberFly_Excel_For_R.xlsx", sheet = 5)
cum_precip_long <- cum_precip %>%
  pivot_longer(cols = -1, names_to = "Year", values_to = "Cumulative_Precipitation")

# Make Graph
ggplot(data = cum_precip_long, mapping = aes(x = Date, y = Cumulative_Precipitation, color = Year)) +
  geom_line() +
  labs(x = "Date", y = "Precipitation [mm]", title = "Cumulative Precipitation in Pierrepont, NY") +
  theme(
    legend.margin = margin(6, 6, 6, 6),
    text = element_text(size=12, family = "CM Roman"), 
    plot.title = element_text(color = "black", face="bold", size=16, hjust=0))
       
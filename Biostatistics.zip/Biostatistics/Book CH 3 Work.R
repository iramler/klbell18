select(compensation, -Root)
slice(compensation, 2)
slice(compensation, 2:10)
slice(compensation, c(2, 3, 10))
with(compensation, Fruit > 80)
filter(compensation, Fruit > 80)
filter(compensation, Fruit > 80 | Fruit < 20)
lo_hi_fruit <- filter(compensation, Fruit > 80 | Fruit < 20)
lo_hi_fruit
head(compensation)
compensation <- mutate(compensation, logFruit = log(Fruit))
head(compensation)
arrange(compensation, Fruit)
select(filter(compensation, Fruit > 80), Root)
compensation %>%
filter(Fruit > 80) %>%  
select(Root)  
compensation %>%
compensation %>%
filter(Fruit > 80)  
compensation %>%
compensation$"Fruit"
compensation %>%
  select(Root)
  filter(Fruit > 80)
compensation %>%
summarise(group_by(compensation, Grazing), meanFruit = mean(Fruit))
summarise(group_by(compensation, Grazing), meanFruit=mean(Fruit))
mean.fruit <- summarise(group_by(compensation, Grazing), meanfruit = mean(Fruit))
compensation %>%
  group_by(Grazing) %>%
  summarise(meanFruit = mean(Fruit))
compensation %>%
  group_by(Grazing) %>%
  summarise(
  meanFruit = mean(Fruit),
  sdFruit = sd(Fruit))
group_by(compensation)
summarise(group_by(compensation, Grazing))
          
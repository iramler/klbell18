# Karina L. Bellavia
# HW 7
# Chapter 3
library(ggplot2)
df <- data.frame(
  x = c(3, 1, 5),
  y = c(2, 4, 6),
  label = c("a", "b", "c")
)
p <- ggplot(df, aes(x, y, label = label)) +
  labs(x = NULL, y = NULL) +
  theme(plot.title = element_text(size = 12))
p + geom_point() + ggtitle("point")
p + geom_text() + ggtitle("text")
p + geom_bar(stat = "identity") + ggtitle("bar")
p + geom_tile() + ggtitle("raster")
p + geom_line() + ggtitle("line")
p + geom_area() + ggtitle("area")
p + geom_path() + ggtitle("path")
p + geom_polygon() + ggtitle("polygon")
df <- data.frame(x = 1, y = 3:1, family = c("sans", "serif", "mono"))
ggplot(df, aes(x, y)) +
  geom_text(aes(label = family, family = family))
df <- data.frame(x = 1, y = 3:1, face = c("plain", "bold", "italic"))
ggplot(df, aes(x, y)) +
  geom_text(aes(label = face, fontface = face))
df <- data.frame(
  x = c(1, 1, 2, 2, 1.5),
  y = c(1, 2, 1, 2, 1.5),
  text = c(
    "bottom-left", "botton-right",
    "top-left", "top-right", "center"
  )
)
ggplot(df, aes(x, y)) +
  geom_text(aes(label = text))
ggplot(df, aes(x, y)) +
  geom_text(aes(label = text), vjust = "inward", hjust = "inward")
df <- data.frame(trt = c("a", "b", "c"), resp = c(1.2, 3.4, 2.5))
ggplot(df, aes(resp, trt)) +
  geom_text(aes(label = paste0("(", resp, ")")), nudge_y = -0.25) +
  xlim(1, 3.6)
ggplot(mpg, aes(displ, hwy)) +
  geom_text(aes(label = model)) +
  xlim(1, 8)
ggplot(mpg, aes(displ, hwy)) +
  geom_text(aes(label = model), check_overlap = TRUE) +
  xlim(1, 8)
label <- data.frame(
  waiting = c(55, 80),
  eruptions = c(2, 4.3),
  label = c("peak one", "peak two")
)
faithfuld
ggplot(faithfuld, aes(waiting, eruptions)) +
  geom_tile(aes(fill = density)) +
  geom_label(data = label, aes(label = label))
ggplot(mpg, aes(displ, hwy, colour = class)) +
  geom_point()
install.packages("directlabels")
ggplot(mpg, aes(displ, hwy, colour = class)) +
  geom_point(show.legend = FALSE) +
  directlabels::geom_dl(aes(label = class), method = "smart.grid")
library(directlabels)
economics
ggplot(economics, aes(date, unemploy)) +
  geom_line()
presidential <- subset(presidential, start > economics$date[1])
ggplot(economics) +
  geom_rect(
    aes(xmin = start, xmax = end, fill = party),
    ymin = -Inf, ymax = Inf, alpha = 0.2,
    data = presidential
  ) +
  geom_vline(
    aes(xintercept = as.numeric(start)),
    data = presidential,
    colour = "grey50", alpha = 0.5
  ) +
  geom_text(
    aes(x = start, y = 2500, label = name),
    data = presidential,
    size = 3, vjust = 0, hjust = 0, nudge_x = 50
  ) +
  geom_line(aes(date, unemploy)) +
  scale_fill_manual(values = c("blue", "red"))
yrng <- range(economics$unemploy)
xrng <- range(economics$date)
caption <- paste(strwrap("Unemployment rates in the US have varied a lot over the years", 40), collapse = "\n")
ggplot(economics, aes(date, unemploy)) +
  geom_line() +
  geom_text(
    aes(x, y, label = caption),
    data = data.frame(x = xrng[1], y = yrng[2], caption = caption),
    hjust = 0, vjust = 1, size = 4
  )
ggplot(economics, aes(date, unemploy)) +
  geom_line() +
  annotate("text", x = xrng[1], y = yrng[2], label= caption, hjust = 0, vjust = 1, size = 4)
ggplot(diamonds, aes(log10(carat), log10(price))) +
  geom_bin2d() +
  facet_wrap(~cut, nrow = 1)
mod_coef <- coef(lm(log10(price) ~log10(carat), data = diamonds))
ggplot(diamonds, aes(log10(carat), log10(price))) +
  geom_bin2d() +
  geom_abline(intercept = mod_coef[1], slope = mod_coef[2], colour = "white", size = 1) +
  facet_wrap(~cut, nrow=1)
mi_counties <- map_data("county", "michigan") %>%
  select(lon = long, lat, group, id = subregion)
head(mi_counties)
ggplot(mi_counties, aes(lon, lat)) +
  geom_polygon(aes(group = group)) +
  coord_quickmap()
ggplot(mi_counties, aes(lon, lat)) +
  geom_polygon(aes(group = group), fill = NA, colour = "grey50") +
  coord_quickmap()
install.packages("USAboundaries")
library("USAboundaries")
mi_cities <- maps::us.cities %>%
  tbl_df() %>%
  filter(country.etc =="MI") %>%
  select(-country.etc, lon = long) %>%
  arrange(desc(pop))
mi_cities
ggplot(mi_cities, aes(lon, lat)) +
  geom_point(aes(size = pop)) +
  scale_size_area() +
  coord_quickmap()
ggplot(mi_cities, aes(lon, lat)) +
  geom_polygon(aes(group = group), mi_counties, fill = NA, colour = "grey50") +
  geom_point(aes(size = pop), colour = "red") +
  scale_size_area() +
  coord_quickmap()
y <- c(18, 11, 16)
df <- data.frame(x = 1:3, y = y, se = c(1.2, 0.5, 1.0))
base <- ggplot(df, aes(x, y, ymin = y - se, ymax = y + se))
base + geom_crossbar()
base + geom_pointrange()
base + geom_smooth(stat = "identity")
base + geom_errorbar()
base + geom_linerange()
base + geom_ribbon()

# Chapter 5
p <- ggplot(mpg, aes(displ, hwy))
p
p + geom_point()
p + layer(
  mapping = NULL,
  data = NULL,
  geom = "point",
  stat = "identity",
  position = "identity"
)
mod <- loess(hwy ~ displ, data = mpg)
grid <- data_frame(displ = seq(min(mpg$displ), max(mpg$displ), length = 50))
grid$hwy <- predict(mod, newdata = grid)
grid
std_resid <- resid(mod)/mod$s
outlier <- filter(mpg, abs(std_resid) > 2)
outlier
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  geom_line(data = grid, colour = "blue", size = 1.5) +
  geom_text(data = outlier, aes(label = model))
ggplot(mpg, aes(displ, hwy)) +
  geom_point(data = mpg) +
  geom_line(data = grid) +
  geom_text(data = outlier, aes(label = model))
ggplot(mpg) +
  geom_point(aes(displ, hwy, colour = class))
ggplot(mpg, aes(displ, hwy, colour = class)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  theme(legend.position = "none")
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(colour = class)) +
  geom_smooth(method = "lm", se = FALSE) +
  theme(legend.position = "none")
ggplot(mpg, aes(cty, hwy)) +
  geom_point(colour = "darkblue")
ggplot(mpg, aes(cty, hwy)) +
  geom_point(aes(colour = "darkblue"))
ggplot(mpg, aes(cty, hwy)) +
  geom_point(aes(colour = "darkblue")) +
  scale_colour_identity()
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  geom_smooth(aes(colour = "loess"), method = "loess", se = FALSE) +
  geom_smooth(aes(colour = "lm"), method = "lm", se = FALSE) +
  labs(colour = "Method")
ggplot(mpg, aes(trans, cty)) +
  geom_point() +
  stat_summary(geom = "point", fun.y = "mean", colour = "red", size = 4)
ggplot(diamonds, aes(price)) +
  geom_histogram(binwidth = 500)
ggplot(diamonds, aes(price)) +
  geom_histogram(aes(y = ..density..), binwidth = 500)
ggplot(diamonds, aes(price, colour = cut)) +
  geom_freqpoly(binwidth = 500) +
  theme(legend.position = "none")
ggplot(diamonds, aes(price, colour = cut)) +
  geom_freqpoly(aes(y = ..density..), binwidth = 500) +
  theme(legend.position = "none")
dplot <- ggplot(diamonds, aes(color, fill = cut)) +
  xlab(NULL) + ylab(NULL) + theme(legend.position = "none")
dplot + geom_bar()
dplot + geom_bar(postion = "fill")
dplot + geom_bar(position = "dodge")
dplot + geom_bar(position = "identity", alpha = 1/2, colour = "grey50")
ggplot(diamonds, aes(color, colour = cut)) +
  geom_line(aes(group = cut), stat = "count") +
  xlab(NULL) + ylab(NULL) +
  theme(legend.position = "none")
ggplot(mpg, aes(displ, hwy)) +
  geom_point(position = "jitter") 
ggplot(mpg, aes(displ, hwy)) +
  geom_point(position = position_jitter(width = 0.05, height = 0.5))
ggplot(mpg, aes(displ, hwy)) +
  geom_jitter(width = 0.05, height = 0.5)

#Chapter 6
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(colour = class)) +
  scale_x_continuous() +
  scale_y_continuous() +
  scale_colour_discrete()
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(colour = class) +
  scale_x_continuous("A really awesome x axis") +
  scale_y_continuous("A really awesome y axis")
ggplot(mpg, aes(displ, hwy)) +
   geom_point() +
  scale_x_continuous("Label 1") +
  scale_y_continuous("Label 2")
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  scale_x_continuous("Label 2")
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(colour = class)) +
  scale_x_sqrt() + 
  scale_colour_brewer()
df <- data.frame(x = 1:2, y = 1, z = "a")
p <- ggplot(df, aes(x,y)) + geom_point()
p + scale_x_continuous("X axis")
p + scale_x_continuous(quote(a + mathematical ^ expression))
p <- ggplot(df, aes(x,y)) + geom_point(aes(colour = z))
p +
  xlab("X axis") +
  ylab("Y axis")
p + labs( x = "X axis", y = "Y axis", colour = "Colour\nlegend")
p <- ggplot(df, aes(x, y)) +
  geom_point() +
  theme(plot.background = element_rect(colour = "grey 50"))
p + labs(x = "", y = "")
p + labs( x = NULL, y = NULL)
df <- data.frame(x = c(1, 3, 5) * 1000, y = 1)
axs <- ggplot(df, aes(x, y)) +
  geom_point() +
  labs(x = NULL, y = NULL)
axs
axs + scale_x_continuous(breaks = c(2000, 4000))
axs + scale_x_continuous(breaks = c(2000, 4000), labels = c("2k", "4k"))
leg <- ggplot(df, aes(y, x, fill = x)) +
  geom_tile() +
  labs(x = NULL, y = NULL)
leg
leg + scale_fill_continuous(breaks = c(2000, 4000))
leg + scale_fill_continuous(breaks = c(2000, 4000), labels = c("2k", "4k"))
df2 <- data.frame(x = 1:3, y = c("a", "b", "c"))
ggplot(df2, aes(x,y)) +
  geom_point()
ggplot(df2, aes(x,y)) +
  geom_point() +
  scale_y_discrete(labels = c(a = "apple", b = "banana", c = "carrot"))
axs + scale_x_continuous(breaks = NULL)
axs + scale_x_continuous(labels = NULL)
leg + scale_fill_continuous(breaks = NULL)
leg + scale_fill_continuous(labels = NULL)
axs + scale_y_continuous(labels = scales::percent_format())
axs + scale_y_continuous(labels = scales::dollar_format())
leg + scale_fill_continuous(labels = scales::unit_format("k"))
df <- data.frame(x = c(2, 3, 5, 10, 200, 3000), y = 1)
ggplot(df, aes(x, y)) +
  geom_point() +
  scale_x_log10()
mb <- as.numeric(1:10 %o% 10 ^ (0:4))
ggplot(df, aes(x,y)) +
  geom_point() +
  scale_x_log10(minor_breaks = log10(mb))
df <- as.data.frame(x = c(1, 2, 3), y = c(1, 2, 3))
ggplot(df, aes(y, y)) +
  geom_point(size = 4, colour = "grey20") +
  geom_point(aes(colour = "z"), size = 2)
norm <- data.frame(x = rnorm(1000), y = rnorm(1000))
norm$z <- cut(norm$x, 3, labels = c("a", "b", "c"))
ggplot(norm, aes(x,y)) +
  geom_point(aes(colour = z), alpha = 0.1)
ggplot(norm, aes(x,y)) +
  geom_point(aes(colour = z), alpha = 0.1) +
  guides(colour = guide_legend(override.aes = list(alpha = 1)))
df <- data.frame(x = 1:3, y = 1:3, z = c("a", "b", "c"))
base <- ggplot(df, aes(x, y)) +
  geom_point(aes(colour = z), size = 3) 
base + theme(legend.position = "bottom")
base + theme(legend.position = c(0,1), legend.justification = c(0,1))
df <- data.frame(x = 1, y = 1:3, z = 1:3)
base <- ggplot(df, aes(x, y)) + geom_raster(aes(fill = z))
base
base + scale_fill_continuous(guide = guide_legend())
base + guides(fill = guide_legend())
df <- data.frame(x = 1, y = 1:4, z = letters[1:4])
p <- ggplot(df, aes(x, y)) + geom_raster(aes(fill = z))
p
p + guides(fill = guide_legend(ncol = 2, bycol = TRUE))
df <- data.frame(x = 1:3, y = 1:3)
base <- ggplot(df, aes(x, y)) + geom_point()
base
base +
  scale_x_continuous(limits = c(1.5, 2.5))
base +
  scale_x_continuous(limits = c(0, 4))
base +
  xlim(4, 0)
base + lims(x = c(0,4))
ggplot(faithfuld, aes(waiting, eruptions)) +
  geom_raster(aes(fill = density)) +
  theme(legend.position = "none")
ggplot(faithfuld, aes(waiting, eruptions)) +
  geom_raster(aes(fill = density)) +
  scale_x_continuous(expand = c(0,0)) +
  scale_y_continuous(expand = c(0,0)) +
  theme(legend.position = "none")
df <- data.frame(x = 1:5)
p <- ggplot(df, aes(x, 1)) + geom_tile(aes(fill = x), colour = "white")
p
p + scale_fill_gradient(limits = c(2,4))
p + scale_fill_gradient(limits = c(2,4), oob = scales::squish)
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  scale_y_continuous(trans = "reciprocal")
ggplot(diamonds, aes(price, carat)) +
  geom_bin2d() +
  scale_x_continuous(trans = "log10") +
  scale_y_continuous(trans = "log10")
base <- ggplot(economics, aes(date, psavert)) +
  geom_line(na.rm = TRUE) +
  labs(x = NULL, y = NULL)
base
base + scale_x_date(date_labels = "%y", date_breaks = "5 years")
base + scale_x_date(limits = as.Date(c("2004-01-01", "2005-01-01")), date_labels = "%b %y", date_minor_breaks = "1 month")
# HW 5.3.1.2
class <- mpg %>%
  group_by(class) %>%
  summarise(n = n(), hwy = mean(hwy))
class
ggplot(mpg, aes(class, hwy)) +
  geom_jitter() +
  geom_point(data = class, colour = "red", size = 7) +
  geom_text(data = class, aes(x = class, y = 0, label = paste("n =", n)))

#HW 5.4.3.1
ggplot(mpg) +
  geom_point(aes(mpg$displ, mpg$hwy))
# SIMPLIFIED TO
ggplot(mpg, aes(displ, hwy)) +
  geom_point()

ggplot() + 
  geom_point(mapping = aes(y = hwy, x = cty), data = mpg) +
  geom_smooth(data = mpg, mapping = aes(cty, hwy))
# SIMPLIFIED TO
ggplot(mpg, aes(cty, hwy)) +
  geom_point() +
  geom_smooth(data = mpg, mapping = aes(cty, hwy))

ggplot(diamonds, aes(carat, price)) +
  geom_point(aes(log(brainwt), log(bodywt)), data = msleep)
#SIMPLIFIED TO
ggplot(msleep, aes(log(brainwt), log(bodywt))) +
  geom_point() +
  labs(x = "carat", y = "price")

View(msleep)
# HW 6.2.1.2
ggplot(mpg, aes(displ)) +
  scale_y_continuous("Highway mpg") +
  scale_x_continuous() +
  geom_point(aes(y = hwy))
#SIMPLIFIED TO
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  scale_y_continuous("Highway mpg")

ggplot(mpg, aes(y = displ, x = class)) +
  scale_y_continuous("Displacement (1)") +
  scale_x_discrete("Car type") +
  scale_x_discrete("Type of car") +
  scale_colour_discrete() + 
  geom_point(aes(colour = drv)) +
  scale_colour_discrete("Driven\ntrain")
#SIMPLIFIED TO
ggplot(mpg, aes(class, displ)) +
  geom_point(aes(colour = drv)) +
  scale_x_discrete("Type of Car") +
  scale_y_continuous("Displacement (1)") +
  scale_colour_discrete("Driven\ntrain")
  
# 6.3.3.1
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  scale_x_continuous("Displacement", labels = scales::unit_format(suffix = "L")) +
  scale_y_continuous(quote(Highway (frac(miles, gallon))))

# 6.4.4.2
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(colour = drv, shape = drv)) +
  scale_colour_discrete("Drive train")
#CHANGE TO
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(colour = drv, shape = drv))

#6.4.4.3
ggplot(mpg, aes(displ, hwy, colour = class)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  theme(legend.position = "bottom") +
  guides(colour = guide_legend(nrow = 1, byrow = TRUE))

#HW A
ny_counties <- map_data("county", "new york") %>%
  select(lon = long, lat, group, id = subregion)
head(ny_counties)
caption <- paste(strwrap("Excelsior", 40), collapse = "\n")
ggplot(ny_counties, aes(lon, lat)) +
  xlab(label = NULL) +
  ylab(label = NULL) +
  geom_polygon(aes(group = group), fill = NA, colour = "grey50") +
  geom_text(aes(x= -73.75, y= 42.65, label = "Albany, NY", fontface = "bold")) +
  annotate(x = -78, y = 41, "text", label = caption, fontface = "italic") +
  coord_quickmap()

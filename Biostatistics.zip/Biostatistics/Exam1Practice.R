# Karina L. Bellavia
# September 25th, 2020
# Practice Exam 1
cat <- seq(from = 0, to = 100, by = 5)
cat
cat[c(1,4,13)]
Information <- c("Canton", "Potsdam", "Madrid", "Colton", 17, NA, 5, 3, 20, 31, 12, 4)
dim(Information) <- c(4, 3)
View(Information)
colnames(Information) <- c("City", "Male", "Female")
View(Information)
rownames(Information) <- c()
Information.df <- as.data.frame(Information)
str(Information)
City <- c("Canton", "Potsdam", "Madrid", "Colton")
Male <- c(17, NA, 5, 3)
Female <- c(20, 31, 12, 4)
Info <- cbind.data.frame(City, Male, Female)
View(Info)
str(Info)
Information$City <- as.character(Information$City)
Exam1 <- Exam1 %>%
  filter(pH > 7.0)
Research <- Exam1 %>%
  select(pool, pH, DO.mg.L)
View(Research)
#Practice problems: Wkst 1
sum((1:100)^2)
y <- seq(1, 1000)
y <- y[y/7 == trunc(y/7)]
sum(y)
B <- c(120, 172, 163, 158, 153, 148, 160, 170, 155, 167, 22, 52, 71, 51, 51, 60, 50, 67, 53, 64)
dim(B) <- c(10, 2)
names <- c("Niece", "Son", "Grandpa", "Daughter", "Yai", "Grandma", "Aunty", "Uncle", "Mom", "Dad")
colnames(B) <- c("ht", "wt")
B
B <- as.data.frame(B)
BMI <- (B$wt)/(B$ht)^2
sort(BMI)
summary(BMI)

C <- seq(1:20)
dim(C) <- c(2,10)
C
g <- rbind(1:10, 11:20)
g
g[ ,seq(from = 1, to = 10, by = 2)]
Diseased <- c(15, 30)
Nondiseased <- c(20, 22)
Illness <- cbind(Diseased, Nondiseased)
rownames(Illness) <- c("Exposed", "Nonexposed")
Illness
Illness <- as.table(Illness)
summary(Illness)
fisher.test(Illness)

sum(Bird$"1982")
Egg <- Bird$"Species List"
Borb <- Bird$"2000"
Berb <- cbind(Egg, Borb)
Berb
?t
Bird <- t(Bird)
View(Bird)
nrow(Bird)
dim(Bird)[1]
Night1 <- read_excel("rstudioshared/KHoffmann/Biostats 2020/night_used_random_data.xlsx")

View(Night1)
Night1 <- as.data.frame(Night1)
library(lubridate)
library(dplyr)
str(Night1)
Night1$"Frog name" <- as.factor(Night1$"Frog name")
Night1$behavior <- as.factor(Night1$behavior)
Night1$Date <- dmy_hm(paste(Night1$Day, Night1$Month, Night1$Year, Night1$Hour, Night1$Minute))
Night1 <- Night1 %>%
  select(-"Time", -"Year", -"Month", -"Day", -"Hour", -"Minute")
Night1 <- Night1 %>%
  filter(`Frog name` != "Rainmaker") %>%
  arrange(Date)
T <- Night1 %>%
  slice(57:64) %>%
  arrange(Date)
View(Night1)
View(T)
Night1 %>%
  arrange(Date) %>%
  filter(Night1$"Date" >= as.Date("2017-04-15"))
class(Night1$"Frog name")
levels(T$"Frog name")
table(Night1$"Frog name")

rm(list = ls())
library(ggplot2)
#First, we need a data set to draw as locations for bombs
#Let's name this data frame "Damage"
#Damage needs to have 3 columns named "Which_Sea", "Sea_x", and "Sea_y" (put in 2 rows for now)
Damage <- (matrix(ncol = 4, nrow = 2))
colnames(Damage) <- c("Which_Sea", "Sea_x","Sea_y", "Target")
#Make Damage into a data frame and set the Sea_x and Sea_y columns as numeric
Damage <- as.data.frame(Damage)
#we need some data for the plot to work, so let's bomb the middle of both seas at (5,5)
# set the values of the first row of Damage to "Mine", 5, and 5
#and the values of the second row to "Opponent", 5, and 5
Damage[1,]<- c("Mine",5,5,"Miss")
Damage[2,]<- c("Opponent",5,5,"Miss")
#And assign classes
Damage$Sea_x <- as.numeric(Damage$Sea_x)
Damage$Sea_y <- as.numeric(Damage$Sea_y)
Damage$Target <- as.factor(Damage$Target)
Damage$Which_Sea <- as.factor(Damage$Which_Sea)
str(Damage) #double checking classes
View(Damage)
#Create graphs representing two seas using faceting,
#with the continuous x and y limits set to (1,10),
# break at every integer from 1 to 10,

#"Battle Ship" as the plot title,
# and big points shaped like asterisks to show our exploding bombs

#Use color to indicate when a bomb hit its target (hint: aes( ))

ggplot(Damage, aes(x = Sea_x, y = Sea_y, colour = Target)) +
  geom_point(size = 5, pch = 8) +
  facet_wrap(~Which_Sea) +
  ggtitle("Battle Ship") +
  scale_x_continuous(limits = c(1, 10), breaks = c(1:10)) +
  scale_y_continuous(limits = c(1, 10), breaks = c(1:10))

#PS1
PS1<- data.frame(Which_Sea = "Mine", Ship = "PS", Ship_x=c(1,1), Ship_y=c(1,2))
#PS2
PS2<- data.frame(Which_Sea = "Mine",Ship = "PS", Ship_x=c(6,7), Ship_y=c(6,6))
#PS3
PS3<- data.frame(Which_Sea = "Mine",Ship = "PS", Ship_x=c(7,7), Ship_y=c(3,4))
#Sub1
Sub1<- data.frame(Which_Sea = "Mine",Ship = "Sub", Ship_x=c(9,9,9), Ship_y=c(7,8,9))
#Sub2
Sub2<- data.frame(Which_Sea = "Mine",Ship = "Sub",Ship_x=c(3,4,5), Ship_y=c(2,2,2))
#Sub3
Sub3<- data.frame(Which_Sea = "Mine",Ship = "Sub",Ship_x=c(5,6,7), Ship_y=c(9,9,9))
#BS1
BS1 <- data.frame(Which_Sea = "Mine",Ship = "BS",Ship_x=c(3,3,3,3), Ship_y=c(5,6,7,8))
#BS2
BS2<- data.frame(Which_Sea = "Mine",Ship = "BS",Ship_x=c(5,6,7,8), Ship_y=c(1,1,1,1))
#BS3
BS3<- data.frame(Which_Sea = "Mine",Ship = "BS",Ship_x=c(1,1,1,1), Ship_y=c(6,7,8,9))
#ACC
ACC <- data.frame(Which_Sea = "Mine",Ship = "ACC",Ship_x=c(10,10,10,10,10), Ship_y=c(1,2,3,4,5))
#All My Ships
My_Ships <- (rbind(PS1,PS2, PS3,Sub1, Sub2, Sub3,BS1, BS2,BS3,ACC))
str(My_Ships)

ggplot(Damage, aes(x = Sea_x, y = Sea_y)) +
  geom_point(aes(colour = Target), size = 5, pch = 8) +
  facet_wrap(~Which_Sea) +
  ggtitle("Battle Ship") +
  scale_x_continuous(limits = c(1, 10), breaks = c(1:10)) +
  scale_y_continuous(limits = c(1, 10), breaks = c(1:10)) +
  geom_point(data = My_Ships, aes(x = Ship_x, y = Ship_y, shape = Ship))

#Use this code to take turns

#REPLACE ZEROS WITH COORDINATES
Damage<-rbind(Damage, data.frame("Which_Sea"="Mine", "Sea_x"=0,"Sea_y"=0, "Target"="Miss"))
Damage<-rbind(Damage, data.frame("Which_Sea"="Opponent", "Sea_x"=0,"Sea_y"=0, "Target"="Hit"))

#Note that if you make a mistake, you can't go back because you are rewriting Damage each time

#RERUN YOUR PLOT AS YOU GO TO SEE WHERE HAS BEEN BOMBED

####REVIEW PART 2####  

install.packages("PerformanceAnalytics") #skip this line if the package is already installed
library(PerformanceAnalytics)
library(readxl)
Riddle <-  read_excel("rstudioshared/KHoffmann/Biostats 2020/Halloween Review/pairplot.xlsx")
chart.Correlation(Riddle, histogram=TRUE, pch=19)
# COFFIN

Cleveland <- c(2,3,1,2,1,3,2,2,1,3,2,1,2,3,1,2,1,2,4,7,10,11,11, 11,9, 7, 9, 10, 11, 12,9, 12,12,12,9, 12,11,10,9,7,9,11,11,11,10,7,4,2)
Cleveland_data <- data.frame(Cleveland, x = (1:length(Cleveland)))
ggplot(Cleveland_data, aes(y = Cleveland, x = 1:length(Cleveland))) +
  geom_point()
# No this is heterogeneity 

Candy <- read_excel("rstudioshared/KHoffmann/Biostats 2020/Halloween Review/AICc.xlsx")
View(Candy)
Zombie <- lm(CandyMissing ~ DeadSkin + DeadFlies + PutridSmell, data = Candy)
WearWolf <- lm(CandyMissing ~ PawPrints + DogHair + Moonrise, data = Candy)
GiantSpider <- lm(CandyMissing ~ Webs + FootSteps, data = Candy)
Suspects <- list( "Zombie" = Zombie, "Wear_Wolf" = WearWolf, "Giant_Spider" = GiantSpider )
aictab(cand.set = Suspects, second.ord = TRUE, sort = TRUE)
#The WearWolf likely took the candy

# 2.4.1.3
mpg
ggplot(mpg, aes(drv, cty)) +
  geom_point()
ggplot(mpg, aes(drv, hwy)) +
  geom_point()
ggplot(mpg, aes(drv, displ, colour = class)) +
  geom_point()

#2.5.1.2
ggplot(mpg, aes(hwy, displ)) +
  geom_point() +
  facet_wrap(~cyl)
ggplot(mpg, aes(hwy, displ)) +
  geom_point()

#HW 6 Continue
data()
?turkey
data(turkey)
head(turkey)
str(turkey)
ggplot(turkey, aes(Diet, Weight.gain)) +
  geom_point() +
  xlab("Diet") +
  ylab("Weight Gain")
ggplot(turkey, aes(Diet, Weight.gain)) +
  geom_boxplot() +
  xlab("Diet") +
  ylab("Weight Gain")

# Map your Home State
ny_counties <- map_data("county", "new york") %>%
  select(lon = long, lat, group, id = subregion)
head(ny_counties)
caption <- paste(strwrap("Excelsior", 40), collapse = "\n")
ggplot(ny_counties, aes(lon, lat)) +
  geom_polygon(aes(group = group), fill = NA, colour = "grey50") +
  ggtitle("New York") +
  geom_text(aes(x = -73.75, y= 42.65, label = "Albany, NY", fontface = "bold")) +
  annotate(x = -79, y = 41, "text", label = caption, fontface = "italic") +
  xlab(label = NULL) +
  ylab(label = NULL) +
  coord_quickmap()
vt_counties <- map_data("county", "vermont") %>%
  select(lon = long, lat, group, id = subregion)
head(vt_counties)
ggplot(vt_counties, aes(lon, lat)) +
  geom_polygon(aes(group = group), fill = NA, colour = "grey50") +
  geom_text(aes(x = -73.2, y = 44.6, label = "Hans' House", fontface = "bold"))
  
# 5.3.1.2
library(dplyr)
mpg
class <- mpg %>%
  group_by(class) %>%
  summarise(n = n(), hwy = mean(hwy))
ggplot(mpg, aes(class, hwy)) +
  geom_jitter() +
  geom_point(data = class, colour = "red", size = 8) +
  geom_text(data = class, aes(x = class, y = 0, label = paste("n =", n)))

 # 6.2.1.2
ggplot(mpg, aes(displ)) +
  scale_y_continuous("Highway mpg") +
  scale_x_continuous() +
  geom_point(aes(y = hwy))

ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  ylab("Highway mpg")

ggplot(mpg, aes(y = displ, x = class)) +
  scale_y_continuous("Displacement (1)") +
  scale_x_discrete("Car type") +
  scale_x_discrete("Type of car") +
  scale_colour_discrete() + 
  geom_point(aes(colour = drv)) +
  scale_colour_discrete("Driven\ntrain")

ggplot(mpg, aes(class, displ)) +
  geom_point(aes(colour = drv)) +
  scale_x_discrete("Car type") +
  scale_y_continuous("Displacement (1)") +
  scale_colour_discrete("Driven\ntrain")

# 6.3.3.1
?quote
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  scale_x_continuous("Displacement", labels = scales::unit_format(suffix = "L")) +
  scale_y_continuous(quote(Highway (frac(miles, gallons))))

#6.4.4.2
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(colour = drv, shape = drv)) +
  scale_colour_discrete("Drive train")

ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(color = drv)) +
  scale_colour_discrete("Drive train") 

#6.4.4.3
ggplot(mpg, aes(displ, hwy, colour = class)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE) +
  theme(legend.position = "bottom") +
  guides(colour = guide_legend(nrow = 1))

ggplot(mpg, aes(displ, hwy)) +
  geom_point(colour = "blue")


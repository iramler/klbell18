# Karina L. Bellavia
# 14 September, 2020
# Analyze the night data of frogs
night_used_random_data <- read_excel("rstudioshared/KHoffmann/Biostats 2020/night_used_random_data.xlsx")
Night <- night_used_random_data
library(lubridate)
library(dplyr)
Night$"Frog name" <- as.factor(Night$"Frog name")
Night$"behavior" <- as.factor(Night$"behavior")
Night$Time <- dmy_hm(paste(Night$"Day", Night$"Month", Night$"Year", Night$"Hour", Night$"Minute"))
Night$Time
Night <- select(Night, -Day, -Month, -Year, -Hour, -Minute)
Night <- Night %>%
  filter(`Frog name` != "Rainmaker") %>%
  arrange(Time)
Water <- Night$Water
hist(Water )
Grass <- Night$Grass
hist(Grass)
WoodyDebris <- Night$woody.debris
hist(WoodyDebris)
summarise(
  group_by(Night, behavior) ,
  meanWoodyDebris = mean(woody.debris))
summarise(
  group_by(Night, behavior) ,
  meanWater = mean(Water))
summarise(
  group_by(Night, behavior) ,
  meanGrass = mean(Grass))
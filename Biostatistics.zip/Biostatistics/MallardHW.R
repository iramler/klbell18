# NYS Breeding Bird Atlas Data
# The goal is to practice ggplot
# Karina Bellavia
# October 2020

rm(list = ls())
library(ggplot2)
library(dplyr)
library(readr)
Bird <- read_csv("rstudioshared/KHoffmann/Biostats 2020/NYBreedingBirdSurvey.csv")
Bird <- t(Bird)
colnames(Bird) <- Bird[1,]
View(Bird)
Bird <- Bird[-1,]
class(Bird)
Bird <- as.data.frame(Bird)
Bird$Mallard
class(Bird$Mallard)
Bird$Mallard <- as.numeric(Bird$Mallard)
plot(x = row.names(Bird), y = Bird$Mallard)
qplot(x = row.names(Bird), y = Bird$Mallard)
qplot(x = as.numeric(row.names(Bird)), y = Bird$Mallard)
yyy <- as.numeric(row.names(Bird))
ggplot(Bird, aes(x = yyy, y = Mallard)) +
  geom_point(aes(size = 1, color = "red")) +
  ggtitle('Ducks by Years') +
  theme(plot.title = element_text(hjust = 0.5, color = "red", size = 10)) +
  xlab("Year") +
  ylab("Counts of Mallards") +
  theme(axis.title = element_text(size = 10)) +
  theme(legend.position = "none")

# Chapter 4 in Beckerman
glimpse(compensation)
ggplot(compensation, aes(x = Root, y = Fruit, colour = Grazing)) +
  geom_point(size = 5) +
  xlab("Root Biomass") +
  ylab("Fruit Production")
  theme_bw()
  
ggplot(compensation, aes(x = Root, y = Fruit, shape = Grazing)) +
    geom_point(size = 5) +
    xlab("Root Biomass") +
    ylab("Fruit Production")
  theme_bw()
  
ggplot(compensation, aes(x = Grazing, y = Fruit)) +
  geom_boxplot() +
  geom_point(size = 4, colour = 'lightgrey', alpha = 0.5) +
  xlab("Grazing treatment") +
  ylab("Fruit Production") +
  theme_bw()

ggplot(compensation, aes(x = Fruit)) +
  geom_histogram(bins = 10)
  
ggplot(compensation, aes(x = Fruit)) +
  geom_histogram(binwidth = 15) +
  facet_wrap(~Grazing)

library(ggplot2)
mpg 
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point() 
ggplot(mpg, aes(displ, cty, colour = class)) +
  geom_point() 
ggplot(mpg, aes(displ, hwy)) +
  geom_point(aes(colour = "blue"))
ggplot(mpg, aes(displ, hwy)) +
  geom_point(colour = "blue")
ggplot(mpg, aes(drv, cty)) +
  geom_point()
ggplot(mpg, aes(drv, hwy)) +
  geom_point()
ggplot(mpg, aes(drv, displ, colour = class)) +
  geom_point()
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  facet_wrap(~class)
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  facet_wrap(~cyl)
?mpg
data()
?catsM
data(catsM)
head(catsM)
str(catsM)
ggplot(catsM, aes(Bwt, Hwt)) +
  geom_point() +
  xlab("Body Weight (kg)") +
  ylab("Heart Weight (g)")
# We can see here that as body weight increases, heart weight will also increase,
# proving that thicker cats have more love to give.
ggplot(catsM, aes(Bwt)) +
  geom_histogram(bins = 10) +
  xlab("Body Weight (kg)") 

# Karina L. Bellavia
# 04 September, 2020
# This code is an analysis of bird species richness and abundance
# of NYS between the years of 1966 and 2017.
names(NYBreedingBirdSurvey)
head(NYBreedingBirdSurvey)
dim(NYBreedingBirdSurvey)
str(NYBreedingBirdSurvey)
glimpse(NYBreedingBirdSurvey)
tibble::as_tibble(NYBreedingBirdSurvey)
sum(NYBreedingBirdSurvey$X1982)
NYBreedingBirdSurvey[,"2000"]
help(t)
Bird <- t(NYBreedingBirdSurvey)
ncol(NYBreedingBirdSurvey)     
dim(NYBreedingBirdSurvey)[1] 
View(NYBreedingBirdSurvey)
View(Bird)
summary(NYBreedingBirdSurvey)
sum(NYBreedingBirdSurvey$"1982")
NYBreedingBirdSurvey[,"2000"]
egg <- NYBreedingBirdSurvey[,"2000"]
NYBreedingBirdSurvey$"2000"
birds <- NYBreedingBirdSurvey[,"Species List"]
cbind(birds, egg)
glimpse(NYBreedingBirdSurvey)
summary(NYBreedingBirdSurvey)
select(NYBreedingBirdSurvey, "2000")

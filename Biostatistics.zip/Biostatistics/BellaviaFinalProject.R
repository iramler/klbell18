# Karina L. Bellavia
# December 4th, 2020
# This is the code for the data analysis of teen
# pregnancy in the United States.
rm(list = ls())
library(ggplot2)
library(dplyr)
library(readxl)
Teen <- read_excel("NCHS_-_U.S._and_State_Trends_on_Teen_Births.xls")
View(Teen)
Teen <- as.data.frame(Teen)
str(Teen)
teen <- Teen %>%
  filter(Age == "15-17 years")
teen <- teen %>%
  filter(State != "Total U.S.")
teen <- as.data.frame(teen)
View(teen)
str(teen)

# Now let's separate by region and find the mean state rate
# Northeast
NE <- teen %>%
  filter(State %in% c("Rhode Island", "Massachusetts", "Connecticut", "New Hampshire", "New York", "Pennsylvania", "New Jersey", "Delaware", "Maryland"))
View(NE)
NE <- NE %>%
  group_by(Year) %>%
  mutate(MeanStateRate = mean(`State Rate`))
NE <- as.data.frame(NE)
str(NE)

# Southeast
SE <- teen %>%
  filter(State %in% c("West Virginia", "Virginia", "Kentucky", "Tennessee", "North Carolina", "South Carolina", "Georgia", "Alabama", "Mississippi", "Arkansas", "Louisiana", "Florida"))
View(SE)  
SE <- SE %>%
  group_by(Year) %>%
  mutate(MeanStateRate = mean(`State Rate`))
SE <- as.data.frame(SE)
str(SE)

# Midwest
MW <- teen %>%
  filter(State %in% c("Ohio", "Indiana", "Michigan", "Illinois", "Missouri", "Wisconsin", "Minnesota", "Iowa", "Kansas", "Nebraska", "South Dakota", "North Dakota"))
View(MW)  
MW <- MW %>%
  group_by(Year) %>%
  mutate(MeanStateRate = mean(`State Rate`))
MW <- as.data.frame(MW)
str(MW)

# Southwest 
SW <- teen %>%
  filter(State %in% c("Texas", "Oklahoma", "New Mexico", "Arizona"))
View(SW)
SW <- SW %>%
  group_by(Year) %>%
  mutate(MeanStateRate = mean(`State Rate`))
SW <- as.data.frame(SW)
str(SW)

# West
W <- teen %>%
  filter(State %in% c("Colorado", "Wyoming", "Montana", "Idaho", "Washington", "Oregon", "Utah", "Nevada", "California", "Alaska", "Hawaii"))
View(W)
W <- W %>%
  group_by(Year) %>%
  mutate(MeanStateRate = mean(`State Rate`))
W <- as.data.frame(W)
str(W)

#QQ Plots
autoplot(lm(teen$`U.S. Birth Rate` ~ teen$Year))
# Not normal, curves at the extremities
autoplot(lm(teen$`State Births` ~ teen$Year))
# Not normal
autoplot(lm(teen$`State Rate` ~ teen$Year))
# Normal until the right extemity
autoplot(lm(teen$`U.S. Births` ~ teen$Year))
# Not normal
autoplot(lm(NE$MeanStateRate ~ NE$Year))
# Not normal, curves at the extremities
autoplot(lm(SE$MeanStateRate ~ SE$Year))
# Relatively normal, curves at the extremities
autoplot(lm(MW$MeanStateRate ~ MW$Year))
# Relatively normal, curves at the extremities
autoplot(lm(SW$MeanStateRate ~ SW$Year))
# Nor normal, curves at the extremities
autoplot(lm(W$MeanStateRate ~ W$Year))
# Not normal, curves at the extremities

# Boxplots
ggplot(teen, aes(teen$`State Rate`)) +
  geom_boxplot()
# There are outliers in the plot 
ggplot(teen, aes(teen$`State Births`)) +
  geom_boxplot()
# There are many outliers in the plot 
ggplot(teen, aes(teen$`U.S. Births`)) +
  geom_boxplot()
# No outliers
ggplot(teen, aes(teen$`U.S. Birth Rate`)) +
  geom_boxplot()
# No outliers
ggplot(NE, aes(MeanStateRate)) +
  geom_boxplot()
# No outliers
ggplot(SE, aes(MeanStateRate)) +
  geom_boxplot()
# No outliers
ggplot(MW, aes(MeanStateRate)) +
  geom_boxplot()
# No outliers
ggplot(SW, aes(MeanStateRate)) +
  geom_boxplot()
# No outliers
ggplot(W, aes(MeanStateRate)) +
  geom_boxplot()
# No outliers

pairs(teen$Year ~ teen$`State Rate` + teen$`State Births` + teen$`U.S. Births` + teen$`U.S. Birth Rate`, data = teen)
# This looks WACK, only thing that makes sense is US births and
# US birth rates
# I did not make a pairplot of the mean because
# it just shows it graphed out.

# 11.7a) Research Question
# How does teen birth rates vary by year? How about by region?

# 11.7b) Dependent variables?
# Mean state rate

# 11.7c) Predictor variables?
# Year and region

# 11.7d) Any appear not normal?
# All were not normal, with many curving at the
# extremities.

# 11.7e) Any outliers?
# All had outliers except the mean state rates.

# 11.7f) Any collinear?
# US births and birth rates

# 12.1) The predictor variable I will use is the year, and
# the dependent variables I will look at are mean state rate
# per region and state rate.

# 12.2) Since I have a continuous dependent variable,
# it is best to use a linear regression. This means I will
# likely calculate a Chi-squared.

# 12.3) I hypothesize that there will be a decrease in teen
# pregnancies for the entire country due to a push in
# sex education and ease of access to contraceptives.

# 12.3) I hypothesize that there will be a decrease in teen
# pregnancies for each region due to a push in
# sex education and ease of access to contraceptives.

# 12.4) ?

# 12.5) # I will be using a linear regression to comprehend
# the change of the mean overtime. I will also be using
# point plots for a visual representation of change.

# The entire country
ggplot(teen, aes(Year, teen$`U.S. Birth Rate`)) +
  geom_point(colour = "purple") +
  ylab("U.S. Birth Rate") +
  ggtitle("U.S. Birth Rate of Females Aged 15-17")

# North East
# By State
ggplot(NE, aes(Year, `State Rate`, colour = State)) +
  geom_point() +
  ylab("State Birth Rate") +
  ggtitle("Northeast")
# Mean State Rate
ggplot(NE, aes(Year, MeanStateRate)) +
  geom_point(colour = "darkblue") +
  ylab("Mean Birth Rate") +
  ggtitle("Northeast")
summary(lm(NE$`State Rate` ~ NE$Year))

# Southeast
# By State
ggplot(SE, aes(Year, `State Rate`, colour = State)) +
  geom_point() +
  ylab("State Birth Rate") +
  ggtitle("Southeast")
# Mean State Rate
ggplot(SE, aes(Year, MeanStateRate)) +
  geom_point(colour = "orange") +
  ylab("Mean Birth Rate") +
  ggtitle("Southeast")

#Mid West
#By State
ggplot(MW, aes(Year, `State Rate`, colour = State)) +
  geom_point() +
  ylab("State Birth Rate") +
  ggtitle("Midwest")
# Mean State Rate
ggplot(MW, aes(Year, MeanStateRate)) +
  geom_point(colour = "yellow3") +
  ylab("Mean Birth Rate") +
  ggtitle("Midwest")

#Southwest
#By State
ggplot(SW, aes(Year, `State Rate`, colour = State)) +
  geom_point() +
  ylab("State Birth Rate") +
  ggtitle("Southwest")
# Mean State Rate
ggplot(SW, aes(Year, MeanStateRate)) +
  geom_point(colour = "red") +
  ylab("Mean Birth Rate") +
  ggtitle("Southwest")

#West
#By State
ggplot(W, aes(Year, `State Rate`, colour = State)) +
  geom_point() +
  ylab("State Birth Rate") +
  ggtitle("West")
# Mean State Rate
ggplot(W, aes(Year, MeanStateRate)) +
  geom_point(colour = "darkgreen") +
  ylab("Mean Birth Rate") +
  ggtitle("West")
  
# All five graphs have a trend of an increase after 2005

# By Region
# Indicate region of each state 
W$Region <- "W"
NE$Region <- "NE"
SW$Region <- "SW"
MW$Region <- "MW"
SE$Region <- "SE"
region <- rbind(W, NE, SW, MW, SE)
View(region)

# Linear regression analysis
summary(lm(region$MeanStateRate ~ region$Region))
# Region is very significant in predicting teen pregnancies (f = 116.3, p < 0.01)
# SW had the highest slope (significant increase)

summary(lm(region$MeanStateRate ~ region$Year))
# Year is very significant in predicting teen pregnancy (f = 3160, p > 0.01)

# Making a Results Table

RegionResults<- array(NA,dim=c(5,3))
View(RegionResults)
rownames(RegionResults)<- c("Midwest*", "Northeast", "Southeast", "Southwest", "West")
colnames(RegionResults) <-c("t-value","p-value", "Intercept")
RegionResults[1,1] <- 38.125
RegionResults[1,2] <-"< 2e-16"
RegionResults[1,3] <- 18.6629
RegionResults[2,1] <- -2.928
RegionResults[2,2] <-0.00346
RegionResults[2,3] <- -2.1898
RegionResults[3,1] <- 13.528
RegionResults[3,2] <- "< 2e-16"
RegionResults[3,3] <- 9.3649
RegionResults[4,1] <- 14.677
RegionResults[4,2] <-"< 2e-16"
RegionResults[4,3] <- 14.3690
RegionResults[5,1] <- 2.266
RegionResults[5,2] <- 0.02362
RegionResults[5,3] <- 1.6038
print(RegionResults, quote = FALSE)

AllResults <- array(NA, dim=c(2,2))
rownames(AllResults) <- c("Region", "Year")
colnames(AllResults) <- c("F-statistic", "p-value")
AllResults[1,1] <- 118.5
AllResults[1,2] <- "< 2e-16"
AllResults[2,1] <- 3160
AllResults[2,2] <- "< 2e-16"
print(AllResults, quote = FALSE)

citation("dplyr")
citation("ggplot2")

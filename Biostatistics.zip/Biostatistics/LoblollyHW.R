#################
# Practicing scales and legends on ggplot2
# Karina L. Bellavia
################

rm(list=ls())

library(ggplot2)
library(dplyr)

?Loblolly
head(Loblolly)
summary(Loblolly)
str(Loblolly)
View(Loblolly)

ggplot(Loblolly, aes(age, height, color = Seed)) +
  geom_point() +
  geom_line()

TTrees <- Loblolly %>% filter(Seed %in% c("303", "311", "327"))
TTrees

ggplot(TTrees, aes(age, height, color = Seed)) +
  geom_point() +
  geom_line()

ggplot(TTrees, aes(age, height, color = Seed)) +
  geom_point() +
  geom_line() +
  scale_y_continuous("Height (ft)") +
  scale_x_continuous("Age (years)")

ggplot(TTrees, aes(age, height, color = Seed)) +
  geom_point() +
  geom_line() +
  ylab("Height (ft)") +
  xlab("Age (years)")

ggplot(TTrees, aes(age, height, color = Seed)) +
  geom_point() +
  geom_line() +
  ylab("Height (ft)") +
  scale_x_continuous("Age", breaks = c(10,20), labels = c("stage 1", "stage 2")) +
  scale_color_discrete("Loblolly Trees", labels = c("Tree 1", "Tree 2", "Tree 3"))

ggplot(TTrees, aes(age, height, color = Seed)) +
  geom_point() +
  geom_line() +
  ylab(quote("Height (ft)")) +
  scale_x_continuous("Age", breaks = c(10,20), labels = c("stage 1", "stage 2")) +
  scale_color_discrete("Loblolly \n Trees", labels = c("Tree 1", "Tree 2", "Tree 3"))

ggplot(TTrees) +
  geom_point(aes(age, height, shape = Seed)) +
  geom_line(aes(age, height, color = Seed))
  
ggplot(TTrees) +
  geom_point(aes(age, height, shape = Seed)) +
  geom_line(aes(age, height, color = age))

# Exam 2
# Karina L. Bellavia
# November 9th, 2020
# The purpose of this code is to present the code for
# the BIOL-303

data(iris)
ggplot(iris, aes(Petal.Length, Petal.Width)) +
  geom_point(colour = "red") +
  geom_smooth(method = "lm") +
  facet_wrap(~Species)

data(iris)
ggplot(iris, aes(Petal.Length, Petal.Width, colour = Species)) +
  geom_point()

library(readr)
L <- read_csv("rstudioshared/KHoffmann/Biostats 2020/Jellyfish Book Data/ladybirds.csv")
View(L)
a <- lm(number ~ Habitat, data = L)
b <- lm(number ~ Site, data = L)
c <- lm(number ~ colour, data = L)
Lmodels <- list(a, b, c)
library(AICcmodavg)
aictab(cand.set = Lmodels, second.ord = TRUE, sort = TRUE)
# Model a best explains the number of bugs observed.


H <- read.csv("~/rstudioshared/KHoffmann/Biostats 2020/HubbardBrookVegData.txt", comment.char="#")
View(H)
H <- as.data.frame(H)
library(dplyr)
HForest <- H %>%
  select(Zone, Species, Dbh, Vigor, AbvBmss, BlwBmss, ElevB)
View(HForest)
str(HForest)
HForest$Vigor <- as.factor(HForest$Vigor)
HForest$Zone <- as.factor(HForest$Zone)
head(HForest)
HForest <- HForest %>%
  group_by(Species) %>%
  mutate(MeanDbh = mean(Dbh), MeanAbvBmss = mean(AbvBmss), MeanBlwBmss = mean(BlwBmss)) 
Zone1Trees <- HForest %>%
  filter(Zone == 1)
ggplot(Zone1Trees, aes(Dbh, AbvBmss, colour = Vigor)) +
  geom_point() +
  scale_colour_manual(values = c("green", "yellow", "#b5651d", "#654321", "black"))
StripedMaples <- HForest %>%
  filter(Species == "ACPE")
View(StripedMaples)
A <- lm(AbvBmss ~ Vigor, data = StripedMaples)
B <- lm(AbvBmss ~ Zone, data = StripedMaples)
C <- lm(AbvBmss ~ ElevB, data = StripedMaples)
Hmodels <- list(A, B, C)
aictab(cand.set = Hmodels, second.ord = TRUE, sort = TRUE)
# It appears vigor strongly influences the biomass of striped maples.
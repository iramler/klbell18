# Karina L. Bellavia
# September 21st, 2020
# I will be analyzing a data set about
# tree frogs in Florida.
# My goal is to see how many frogs of each
# species were caught, how captures of each
# species varies over time, how sizes compare, 
# and to explore other variables.
FloridaTreefrogs <- read_csv("rstudioshared/KHoffmann/Biostats 2020/FloridaTreefrogs.csv")
library(plyr)
library(dplyr)
names(FloridaTreefrogs)
dim(FloridaTreefrogs)
View(FloridaTreefrogs)
# The weather abbreviations are inconsistent
# throughout the code.
help(mapvalues)
x <- c("HYFE")
FloridaTreefrogs$species <- mapvalues(FloridaTreefrogs$species, from = c("HYFE"), to = c("Hyfe"))
y <- c("OSSE")
FloridaTreefrogs$species <- mapvalues(FloridaTreefrogs$species, from = c("OSSE"), to = c("Osse"))
Frog <- c("Hyfe", "Osse")
FloridaTreefrogs <- FloridaTreefrogs %>%
  filter(species %in% Frog)
FloridaTreefrogs <- mutate(FloridaTreefrogs, ID = paste(FloridaTreefrogs$species, FloridaTreefrogs$code))
FloridaTreefrogs <- select(FloridaTreefrogs, ID, species, pipe, Date, SVL, weight, temp, Humidity)
str(FloridaTreefrogs)
FloridaTreefrogs$weight <- as.numeric(FloridaTreefrogs$weight, na.rm = T)
FloridaTreefrogs$pipe <- as.character(FloridaTreefrogs$pipe)
FloridaTreefrogs$Humidity <- as.numeric(FloridaTreefrogs$Humidity, na.rm = T)
FloridaTreefrogs$ID <- as.factor(FloridaTreefrogs$ID)
FloridaTreefrogs$species <- as.factor(FloridaTreefrogs$species)
FloridaTreefrogs$Date <- as.character(FloridaTreefrogs$Date)
table(FloridaTreefrogs$species)
# There are 209 Hyfe and 58 Osse.
plot(FloridaTreefrogs$species, FloridaTreefrogs$SVL)
# It appears that Osse have a larger SVL than Hyfe.
plot(FloridaTreefrogs$species, FloridaTreefrogs$weight)
# Although Osse have a larger SVL, it has a similar weight in comparison to Hyfe.
plot(FloridaTreefrogs$species, FloridaTreefrogs$Humidity)
# Hyfe can be found in a larger range of humidity than Osse.
plot(FloridaTreefrogs$species, FloridaTreefrogs$temp)
# Osse is much pickier with temperatures in comparison to Hyfe.

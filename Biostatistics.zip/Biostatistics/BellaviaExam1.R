# Karina L. Bellavia
# September 30th, 2020
# This is the code for exam 1 of Biostatistics at St. Lawrence University.
library(dplyr)
library(readxl)
Class <- read_excel("rstudioshared/KHoffmann/Biostats 2020/Data_on_classmates.xlsx")
View(Class)
Class <- Class %>%
  select(-Interest)
Class <- Class %>%
  mutate("Classmates" = 1:10)
Class$Major <- as.factor(Class$Major)
class(Class$Major)
Class$Major
levels(Class$Major)

Shrimp <- c("Shrimp 1", "Shrimp 2", "Shrimp 3", "Shrimp 4", "Shrimp 1", "Shrimp 2", "Shrimp 3", "Shrimp 4")
Length <- c(1, 4, 2, 1, 3, 6, NA, 4)
Date <- c("Day 1", "Day 1", "Day 1", "Day 1", "Day 2", "Day 2", "Day 2", "Day 2")
cbind("Shrimp", "mm", "Date")
View(ShrimpData)

ShrimpData <- c(1, 1, 1, 1, 2, 2, 2, 2, "Shrimp 1", "Shrimp 2", "Shrimp 3", "Shrimp 4", "Shrimp 1", "Shrimp 2", "Shrimp 3", "Shrimp 4", 1, 4, 2, 1, 3, 6, NA, 4)
dim(ShrimpData) <- c(8, 3)
colnames(ShrimpData) <- c("Date", "Shrimp", "Length")
ShrimpData <- as.data.frame(ShrimpData)
View(ShrimpData)
ShrimpData$Shrimp <- as.factor(ShrimpData$Shrimp)
ShrimpData$Date <- as.numeric(ShrimpData$Date)
ShrimpData$Length <- as.numeric(ShrimpData$Length)
str(ShrimpData)
t(ShrimpData)
nrow(ShrimpData$Length, na.rm = T)
ShrimpData[7,3] <- 1
ShrimpData <- ShrimpData %>%
  filter(Shrimp != "Shrimp 3") %>%
  group_by(Date) %>%
  mutate(Mean1 = mean(Length))
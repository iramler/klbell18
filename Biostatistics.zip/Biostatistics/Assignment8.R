# HW Assignment 8 - Ssex Salamander
# Karina L. Bellavia
# October 25th, 2020
# The purpose of this is to analyze Ssexual salamander
# data and practice various types of statistical tests.

rm(list = ls())
S <- read_excel("SalamanderAssignment8.xlsx")
library(ggplot2)
library(dplyr)
summary(S)
str(S)
S$Genomotype <- as.factor(S$Genomotype)
S$Fate <- as.factor(S$Fate)
S$Pool <- as.factor(S$Pool)
S[27, 13] <- "MU"
table(S$ID)
table(S$Genomotype)
table(S$Clone)
table(S$Weightg)
table(S$SVLmm)
table(S$ReleaseDay)
table(S$DaysTracked)
table(S$Plots0.5m)
table(S$Plots3m)
table(S$MaxStep)
table(S$CumDist)
table(S$Pool)
table(S$PoolDist)
table(S$Fate)
table(S$Year)
table(S$LastDay)
S <- S %>%
  select(-Genomotype)
View(S)
str(S)
s <- S %>%
  select(-ID, -Clone, -ReleaseDay, -Plots0.5m, -Fate, -Pool, -LastDay, -Year)
View(s)
Salamander <- cor(s)
round(Salamander, 2)
s <- s %>%
  select(-CumDist)
ggplot(s, aes( y = Weightg, x = 1:length(Weightg))) +
  geom_point()
# Variance in the plot near the beginning, however seems to
# get more compacted later in the data
ggplot(s, aes(y = SVLmm, x = 1:length(SVLmm))) +
  geom_point()
# There seems to be a great amount of variance in the beginning
# of this plot, but near the end there is a majority of high values.
ggplot(s, aes(y = DaysTracked, x = 1:length(DaysTracked))) +
  geom_point()
# This plot seems to be much more organized, with a separation
# of lower and higher values at y = 62
ggplot(s, aes(y = Plots3m, x = 1:length(Plots3m))) +
  geom_point()
# This seems like a highly organized plot, with a majority of
# the values below y = 7.
ggplot(s, aes(y = MaxStep, x = 1:length(MaxStep))) +
  geom_point()
# The data seems "clustered," with a majority of variables
# between y = 150-250 near the beginning of the data, y = 
# 0-100 in the middle of the data, and y = 150-250 near the
# end of the data.
ggplot(s, aes(y = PoolDist, x = 1:length(PoolDist))) +
  geom_point()
# There is more variance in this data, with a noticeable
# separation of lower and higher values at about x = 30.
autoplot(lm(PoolDist ~ SVLmm, data = s))
# This is relatively a straight line, however data curves
# off near the extremities. There are more extreme values
# than expected.
autoplot(lm(PoolDist ~ Weightg, data = s))
# The data is generally linear, with it curving off near the
# bottom of the line.
autoplot(lm(PoolDist ~ DaysTracked, data = s))
# This QQ plot appears linear, with some curving near the top
# and bottom of the line.
autoplot(lm(PoolDist ~ Plots3m, data = s))
# This is relatively a straight line, however data curves
# off near the extremities. There are more extreme values
# than expected.
autoplot(lm(PoolDist ~ MaxStep, data = s))
# This is not a linear plot, with data appearing as a 
# horizontal line and curvature at the extremities. 
a <- lm(PoolDist ~ Weightg + SVLmm + MaxStep, data = S)
pairs(PoolDist ~ Weightg + SVLmm + MaxStep, data = S)
chart.Correlation(cbind(S$Weightg, S$SVLmm, S$MaxStep), histogram=TRUE, pch=19)
b<- lm(PoolDist ~ MaxStep + Plots3m + CumDist, data = S)
c<- lm(PoolDist ~ MaxStep + CumDist + Weightg, data = S)
d <- lm(PoolDist ~ MaxStep + CumDist + SVLmm, data = S)
e <- lm(PoolDist ~ MaxStep + Fate + Pool, data = S)
salmodels <- list(a, b, c, d, e)
salmodels
install.packages("AICcmodavg")
library(AICcmodavg)
aictab(cand.set = salmodels, second.ord = TRUE, sort = TRUE)
ggplot(S, aes(x = PoolDist, y = MaxStep)) +
  geom_point() +
  geom_smooth()
ggplot(S, aes(x = PoolDist, y = CumDist)) +
  geom_point() +
  geom_smooth()
ggplot(S, aes(x = PoolDist, y = Plots3m)) +
  geom_point() +
  geom_smooth()

str(S)
S$Genomotype <- as.factor(S$Genomotype)
S$Clone <- as.factor(S$Clone)
S$Fate <- as.factor(S$Fate)
S$Pool <- as.factor(S$Pool)
S[27, 13] <- "MU"
table(S$ID) 
table(S$Genomotype)
table(S$Clone)
table(S$Weightg)
table(S$SVLmm)
table(S$ReleaseDay)
table(S$DaysTracked)
table(S$Plots0.5m)
table(S$Plots3m)
table(S$MaxStep)
table(S$CumDist)
table(S$Pool)
table(S$PoolDist)
table(S$Fate)
table(S$Year)
table(S$LastDay)
S <- S %>%
  select(-Genomotype)
str(S)
s <- S %>%
  select(-ID, -Clone, -ReleaseDay, -Plots0.5m, -Fate, -Pool, -LastDay, -Year)
View(s)
Salamander <- cor(s)
Salamander
round(Salamander, 2)
s <- s %>%
  select(-CumDist)
ggplot(s, aes( y = Weightg, x = 1:length(Weightg))) +
  geom_point() # Cleveland Plot
library(ggfortify)
autoplot(lm(PoolDist ~ SVLmm, data = s)) #QQPlot
a <- lm(PoolDist ~ Weightg + SVLmm + MaxStep, data = S)
pairs(PoolDist ~ Weightg + SVLmm + MaxStep, data = S) #Pairplot
b<- lm(PoolDist ~ MaxStep + Plots3m + CumDist, data = S)
c<- lm(PoolDist ~ MaxStep + CumDist + Weightg, data = S)
d <- lm(PoolDist ~ MaxStep + CumDist + SVLmm, data = S)
e <- lm(PoolDist ~ MaxStep + Fate + Pool, data = S)
salmodels <- list(a, b, c, d, e)
salmodels
library(AICcmodavg)
aictab(cand.set = salmodels, second.ord = TRUE, sort = TRUE) #AICModel
ggplot(S, aes(x = PoolDist, y = MaxStep)) +
  geom_point() +
  geom_smooth()
ggplot(S, aes(x = PoolDist, y = CumDist)) +
  geom_point() +
  geom_smooth()
ggplot(S, aes(x = PoolDist, y = Plots3m)) +
  geom_point() +
  geom_smooth()

s[2,2]
s[2]

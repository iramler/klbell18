# Karina L. Bellavia
# 04 September, 2020
# This script is for practice analysis in ggplot2
names(gardens)
head(gardens)
dim(gardens)
str(gardens)
glimpse(gardens)
tbl_df(gardens)

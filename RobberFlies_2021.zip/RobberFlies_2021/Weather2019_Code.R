# Karina L. Bellavia
# June 4th, 2021
# The purpose of this code is to compare the relationships between
# temperature, fly count, and precipitation for 2019

rm(list = ls())
library(readxl)
Weather19 <- read_excel("RobberFlies_2021/Weather2019.xlsx")
library(ggplot2)
library(dplyr)
library(cowplot)
summary(Weather19)
str(Weather19)
View(Weather19)

# Rename headings
colnames(Weather19) <- c("Date", "FlyCount", "Temp", "Precip")

# Make the graph
ggplot(Weather19, aes(x = Date)) +
  geom_line(aes(y = Temp), color = "Red") +
  geom_line(aes(y = FlyCount), color = "Blue") +
  scale_y_continuous("Fly Abundance", sec.axis = sec_axis(~ . + 10, name = "Temperature (C)")) +
  theme(axis.title.y.left = element_text(colour = "blue"),axis.title.y.right = element_text(colour = "red"))

# Make the graph pt 2
ggplot(Weather19, aes(x = Date)) +
  geom_line(aes(y = Temp, colour = "Temperature ")) +
  geom_line(aes(y = FlyCount, colour = "Fly Abundance")) +
  scale_y_continuous(sec.axis = sec_axis(~.*1, name = "Temperature [°C]")) +
  scale_colour_manual(values = c("blue", "red")) +
  labs(y = "Fly Abundance",
       x = "Date",
       colour = "Legend") +
  theme(legend.position = c(0.8, 0.9))

# Make the graph pt 3
p1 <- ggplot(Weather19, aes(x = Date, y = FlyCount)) +
  geom_bar(stat = "identity", color = "Blue") +
  labs(y = "Fly Abundance",
       x = "") +
  ggtitle("Weather and Fly Abundance in Pierrepont, NY 2019")

p2 <- ggplot(Weather19, aes(x = Date, y = Temp)) +
  geom_bar(stat = "identity", color = "Red") +
  labs(y = "Temperature [°C]",
       x = "")

p2 <- ggplot(Weather19, (aes(x= Date))) +
  geom_line(aes(y = Temp), color = "Red") +
  labs(y = "Temperature [°C]",
       x = "")

p3 <- ggplot(Weather19, aes(x = Date, y = Precip)) +
  geom_bar(stat = "identity", color = "DarkGreen") +
  labs(y = "Precipitation [mm]",
       x = "Date")

plot_grid(p1, p2, p3, ncol = 1)


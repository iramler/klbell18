# Karina L. Bellavia
# June 15th, 2021
# The purpose of this code is to compare the monthly hTDD between
# 2019, 2020, and 2021 in Colton, NY

rm(list = ls())
library(readxl)
HTDD <- read_excel("RobberFlies_2021/HTDD_Colton.xlsx")
library(ggplot2)
library(dplyr)
library(cowplot)
summary(HTDD)
str(HTDD)
View(HTDD)

# Make a graph
ggplot(HTDD, aes(x= Month, y = HTDD2019)) +
  geom_bar(stat = "identity", color = "DarkGreen")
